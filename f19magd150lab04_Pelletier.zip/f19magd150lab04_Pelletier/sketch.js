var x=1
function setup() {
  createCanvas(500, 500);
}

function draw() {
  if(keyIsPressed===true)
  {
    background('#FF8D8D')
  }
  else
  {
    background('#F99B0F')
  }


    strokeWeight(10);
  stroke(226, 145, 39);
  fill(240, 213,33);
  ellipse(250,250,330,330);

  noStroke();
  fill(210, 58,47);
  ellipse(300, 300, 35, 35);
  ellipse(175, 130, 25, 25);
  ellipse(150, 250, 25, 30);
  ellipse(300, 200, 30, 30);
  ellipse(200,375,30,30);
  ellipse(340,320,40,40);
  ellipse(130, 310, 30, 30);
  ellipse(250, 150, 20, 20);
  ellipse(200, 200, 40,40);
  ellipse(360,250, 30,30);
  ellipse(225,315, 40,40);
  if(mouseIsPressed)
  {
        strokeWeight(10);
  stroke(226, 145, 39);
  fill(240, 213,33);
  ellipse(250,250,330,330);}
  else
  {
  }
 strokeWeight(2)
fill(192,183,184);
 ellipse(x+0,250,50,50);
  x++;
  
  
}
