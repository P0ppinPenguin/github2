function setup() {
  // put setup code here
  createCanvas(500,500);
  background('#25007F');

}

function draw() {
  // put drawing code here

  noStroke();
  c = color('#FFED0F');
   fill(c);
  triangle(335,77,362,30,387,77);
    triangle(387,45,335,45,362,90);

  triangle(250,115,330,115,295,190);
    triangle(250,165,295,90,330,165);
    noStroke();
    fill(103,5,255)
    arc(50, 50, 80, 80, 0, PI + QUARTER_PI, PIE);
    noFill();
    stroke(255);
    bezier(50,50,125,17,115,126,34,88);





  }
