var x, y;
var xspeed;
function setup() {
  createCanvas(400, 400);
  x=62;
  y=height/2;
  xspeed =3;
}

function draw() {
  background(145, 250, 255);
  strokeWeight(2);
  fill(184, 184, 184);
  rect(50,50,300,300);
    strokeWeight(1);
  fill(84, 64, 33);
  rect(65,350,60,59);
  rect(280,350,60,60);
  fill(0,0,0);
  rect(125,350,155,50);
  fill(181, 38, 9);
  rect(130,352,20,20);
  ellipse(268,359,16,16);
  strokeWeight(2.25);
  line(200,50,67,35);
  line(200,50,350,35);
  textSize(8.75);
  fill(255);
  text("Power", 253,375);
  textSize(8.75);
  fill(255)
  text("Channel", 125, 382);
  if(mouseIsPressed) {
    if(mouseX>130 && mouseX <130+20 && mouseY>352 && mouseY <352+20){
      fill(184, 184, 184);
      rect(130,252,15,15);
      fill(103, 247, 7);
      rect(50,50,300,300);
      
    }
  }
  if(mouseIsPressed) {
    if(mouseX>268 && mouseX <268+16 && mouseY>359 && mouseY <359+16){
      fill(181, 38, 9);
      ellipse(268,359,16,16)
      fill(174, 27, 207)
      rect(50,50,300,300);
    }
  }
  fill(255,255,255);
  ellipse(x,y,30,30)
  x+= xspeed;
  if(x-62 <= 0 || x+62>width){
    xspeed *=-1;
  }
}
