function setup() {
createCanvas(450,450)
}

function draw() {
  background (200);
    fill(255);
     strokeWeight(3);
    rect(300,200,120,250);  


     fill(20,20,60,60);
    strokeWeight(3); 
      rect(337,275,50,50);
      

       fill(51);
    strokeWeight(0);
  (ellipse (45,40,55,55));
 

 
  point(100,50);
    point(200,60);
      point(225,55);
        point(300,40);
          point(350,75);
            point(450,159); 
             point(400,179); 
              point(287,200); 
               point(326,345); 
                point(400,234); 

     
     rectMode(CORNER);
     fill(100);
     rect(350,400,35,50);



       fill(51)
   strokeWeight(2);
   (ellipse(375,425,15,20));
   
     line(336,300,387,300);
     line(362,275,362,325);
}

