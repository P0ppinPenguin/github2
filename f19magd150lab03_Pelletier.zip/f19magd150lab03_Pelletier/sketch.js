var x = 20
var y = 300
var z = 120
var a = 150
var b = 250
var c = 400
function setup() {
  createCanvas(500,500);
  frameRate(30);
}

function draw() {
  background(220);

  fill(3, 219, 252)
  ellipse(x *= 1.05, min(200,150),50,50);
  x++
  fill(3, 219, 252);
  ellipse(50, y -= 4, 35,35);
  y++
    ellipse(mouseX, mouseY, pmouseY);
  print(pmouseY + ' -> ' + mouseY);
  fill(3, 219, 252)
  ellipse(z += 1, a, 90,100);
  z++
  a--
  fill(3,219,252)
  ellipse(b /= 1, max(120,300), 200,200);
  b--
  let c = map(pmouseX, 0, width, 0, 220);
  ellipse(c, 400, 100, 120);

  print('The value of y is ' + y);

}